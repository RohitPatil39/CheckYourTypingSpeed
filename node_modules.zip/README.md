# Practice-Speed-Typing-
This enables you to test your typing speed in words per minute
 along with the feedback showing errors and accuracy.
